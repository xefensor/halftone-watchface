HALFTONE 1.3.0 — PEBBLE STORE RELEASE KIT

Upload Halftone-1.3.0.pbw as a new release of the existing Halftone listing.
Keep UUID d4dd5046-53be-4624-99e8-46e0b377fe66.

This version stores up to six hours of hourly forecasts for offline use.
Estimated readings are marked with ~. Normal refreshes are every 30 minutes.
Weather still uses Pebble first, with Open-Meteo fallback or forecast supplement.

Update the listing with description.txt, release-notes.txt and PRIVACY.md.
Raw 200 × 228 Emery screenshots and the optional banner are in store-assets.
Install this exact PBW on a real Pebble Time 2 before publishing and follow
the weather, offline-cache and settings checks in PUBLISHING.md.

Halftone-1.3.0-source.zip contains clean source, tests and license notices.
SHA256SUMS.txt contains checksums for the binary and source archive.
