HALFTONE 1.2.0 — PEBBLE STORE RELEASE KIT

Upload Halftone-1.2.0.pbw as a new release of the existing Halftone listing.
Keep the existing UUID: d4dd5046-53be-4624-99e8-46e0b377fe66.

Update the description, release notes and privacy disclosure using the included
files. The screenshots in store-assets are raw 200 × 228 Emery captures.
The 720 × 320 banner is optional for a watchface.

Pebble weather is the primary source, with Open-Meteo fallback. The primary
endpoint is internal and may change. The fallback does not depend on it.
Before publishing, install the exact PBW on a real Pebble Time 2 and follow
PUBLISHING.md, especially the weather, reconnection and settings checks.

Halftone-1.2.0-source.zip includes clean source, tests and license notices.
SHA256SUMS.txt contains checksums for the binary and source archive.
