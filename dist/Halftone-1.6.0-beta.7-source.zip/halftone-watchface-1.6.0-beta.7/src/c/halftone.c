#include <pebble.h>
#include "complication_data.h"
#include "watch_layout.h"

#define PERSIST_KEY_BACKGROUND_COLOR 2
#define PERSIST_KEY_TEXT_COLOR 3
#define PERSIST_KEY_DEPTH_EFFECT 4
#define PERSIST_KEY_TEXT_SHADOW 5
#define PERSIST_KEY_LARGE_TEXT 6
#define PERSIST_KEY_USE_12_HOUR 7
#define PERSIST_KEY_LAYOUT_STYLE 16
#define PERSIST_KEY_COMPLICATION_FIRST 20
#define COMPLICATION_CACHE_CHUNKS 8
#define COMPLICATION_CACHE_CHUNK_BYTES 256

#define DOT_OUTER_CORNER_RADIUS 30
#define DOT_SPACING 10
#define CLASSIC_DOT_TRANSITION_STEPS 3
#define DEPTH_DOT_TRANSITION_STEPS 4
#define FULL_LAYOUT_HEIGHT 228
#define TIMELINE_LAYOUT_HEIGHT 171
#define COMPACT_FONT_ENTER_HEIGHT 205
#define COMPACT_FONT_EXIT_HEIGHT 215
#define TIMELINE_DATE_Y 25
#define TIMELINE_TIME_Y 45
#define LARGE_TIME_FONT_COUNT 8
#define COMPLICATION_FONT_COUNT 5

static Window *s_window;
static Layer *s_window_layer;
static Layer *s_background_layer;
static Layer *s_complication_layers[COMPLICATION_SLOT_COUNT];
static TextLayer *s_date_layer;
static TextLayer *s_time_layer;
static TextLayer *s_minutes_layer;
static TextLayer *s_date_shadow_layer;
static TextLayer *s_time_shadow_layer;
static TextLayer *s_minutes_shadow_layer;
static GFont s_date_font;
static GFont s_time_font;
static GFont s_compact_date_font;
static GFont s_small_date_font;
static GFont s_compact_time_font;
static GFont s_large_date_font;
static GFont s_large_time_fonts[LARGE_TIME_FONT_COUNT];
static GFont s_large_compact_time_font;
static GFont s_complication_fonts[COMPLICATION_FONT_COUNT];
static const uint8_t s_complication_font_sizes[COMPLICATION_FONT_COUNT] = {38, 28, 24, 20, 18};
static GColor s_background_color;
static GColor s_text_color;
static bool s_compact_layout;
static bool s_depth_effect_enabled;
static bool s_text_shadow_enabled;
static bool s_large_text_enabled;
static bool s_use_12_hour;
static WatchLayoutStyle s_layout_style;
static ComplicationSet s_complications;
static bool s_has_complications;
static bool s_was_fresh[COMPLICATION_SLOT_COUNT];
static uint8_t s_complication_packet[COMPLICATION_MAX_BYTES];
static size_t s_complication_packet_length;
static AppTimer *s_startup_timer;
static char s_date_buffer[40];
static char s_time_buffer[6];
static char s_hours_buffer[3];
static char s_minutes_buffer[3];

static const char *const s_english_days[] = {
  "SUNDAY",
  "MONDAY",
  "TUESDAY",
  "WEDNESDAY",
  "THURSDAY",
  "FRIDAY",
  "SATURDAY"
};

static const char *const s_czech_days[] = {
  "NEDĚLE", "PONDĚLÍ", "ÚTERÝ", "STŘEDA", "ČTVRTEK", "PÁTEK", "SOBOTA"
};
static const char *const s_slovak_days[] = {
  "NEDEĽA", "PONDELOK", "UTOROK", "STREDA", "ŠTVRTOK", "PIATOK", "SOBOTA"
};
static const char *const s_german_days[] = {
  "SONNTAG", "MONTAG", "DIENSTAG", "MITTWOCH", "DONNERSTAG", "FREITAG", "SAMSTAG"
};
static const char *const s_french_days[] = {
  "DIMANCHE", "LUNDI", "MARDI", "MERCREDI", "JEUDI", "VENDREDI", "SAMEDI"
};
static const char *const s_spanish_days[] = {
  "DOMINGO", "LUNES", "MARTES", "MIÉRCOLES", "JUEVES", "VIERNES", "SÁBADO"
};
static const char *const s_italian_days[] = {
  "DOMENICA", "LUNEDÌ", "MARTEDÌ", "MERCOLEDÌ", "GIOVEDÌ", "VENERDÌ", "SABATO"
};
static const char *const s_portuguese_days[] = {
  "DOMINGO", "SEGUNDA", "TERÇA", "QUARTA", "QUINTA", "SEXTA", "SÁBADO"
};
static const char *const s_dutch_days[] = {
  "ZONDAG", "MAANDAG", "DINSDAG", "WOENSDAG", "DONDERDAG", "VRIJDAG", "ZATERDAG"
};
static const char *const s_polish_days[] = {
  "NIEDZIELA", "PONIEDZIAŁEK", "WTOREK", "ŚRODA", "CZWARTEK", "PIĄTEK", "SOBOTA"
};
static const char *const s_danish_days[] = {
  "SØNDAG", "MANDAG", "TIRSDAG", "ONSDAG", "TORSDAG", "FREDAG", "LØRDAG"
};
static const char *const s_swedish_days[] = {
  "SÖNDAG", "MÅNDAG", "TISDAG", "ONSDAG", "TORSDAG", "FREDAG", "LÖRDAG"
};
static const char *const s_norwegian_days[] = {
  "SØNDAG", "MANDAG", "TIRSDAG", "ONSDAG", "TORSDAG", "FREDAG", "LØRDAG"
};
static const char *const s_finnish_days[] = {
  "SUNNUNTAI", "MAANANTAI", "TIISTAI", "KESKIVIIKKO", "TORSTAI", "PERJANTAI", "LAUANTAI"
};
static const char *const s_hungarian_days[] = {
  "VASÁRNAP", "HÉTFŐ", "KEDD", "SZERDA", "CSÜTÖRTÖK", "PÉNTEK", "SZOMBAT"
};
static const char *const s_romanian_days[] = {
  "DUMINICĂ", "LUNI", "MARȚI", "MIERCURI", "JOI", "VINERI", "SÂMBĂTĂ"
};
static const char *const s_turkish_days[] = {
  "PAZAR", "PAZARTESİ", "SALI", "ÇARŞAMBA", "PERŞEMBE", "CUMA", "CUMARTESİ"
};

static bool prv_locale_is(const char *locale, const char *language) {
  return locale != NULL && locale[0] == language[0] &&
         locale[1] == language[1] &&
         (locale[2] == '\0' || locale[2] == '_' || locale[2] == '-');
}

static const char *const *prv_get_localized_days(void) {
  const char *locale = i18n_get_system_locale();

  if (prv_locale_is(locale, "cs")) return s_czech_days;
  if (prv_locale_is(locale, "sk")) return s_slovak_days;
  if (prv_locale_is(locale, "de")) return s_german_days;
  if (prv_locale_is(locale, "fr")) return s_french_days;
  if (prv_locale_is(locale, "es")) return s_spanish_days;
  if (prv_locale_is(locale, "it")) return s_italian_days;
  if (prv_locale_is(locale, "pt")) return s_portuguese_days;
  if (prv_locale_is(locale, "nl")) return s_dutch_days;
  if (prv_locale_is(locale, "pl")) return s_polish_days;
  if (prv_locale_is(locale, "da")) return s_danish_days;
  if (prv_locale_is(locale, "sv")) return s_swedish_days;
  if (prv_locale_is(locale, "no") || prv_locale_is(locale, "nb") ||
      prv_locale_is(locale, "nn")) return s_norwegian_days;
  if (prv_locale_is(locale, "fi")) return s_finnish_days;
  if (prv_locale_is(locale, "hu")) return s_hungarian_days;
  if (prv_locale_is(locale, "ro")) return s_romanian_days;
  if (prv_locale_is(locale, "tr")) return s_turkish_days;

  return s_english_days;
}

static const int s_classic_dot_depths[CLASSIC_DOT_TRANSITION_STEPS] = {
  0, 7, 14
};
static const int s_classic_dot_radii[CLASSIC_DOT_TRANSITION_STEPS] = {
  4, 2, 1
};
static const int s_depth_dot_depths[DEPTH_DOT_TRANSITION_STEPS] = {
  0, 7, 14, 21
};
static const int s_depth_dot_radii[DEPTH_DOT_TRANSITION_STEPS] = {
  4, 3, 2, 1
};

static int prv_first_grid_point(int start, int origin) {
  int point = origin;
  while (point - DOT_SPACING >= start) {
    point -= DOT_SPACING;
  }
  while (point < start) {
    point += DOT_SPACING;
  }
  return point;
}

static void prv_draw_horizontal_dot_run(GContext *ctx, int y, int start,
                                        int end, int radius, int phase,
                                        int screen_width) {
  const int origin = screen_width / 2 + phase;
  const int first = prv_first_grid_point(start, origin);
  const int center = screen_width / 2;

  // Build the second half by exact pixel reflection. Even-sized displays have
  // no single center pixel, so the unavoidable one-pixel remainder is kept at
  // the side center instead of accumulating as a visibly wrong corner.
  for (int x = first; x < center; x += DOT_SPACING) {
    graphics_fill_circle(ctx, GPoint(x, y), radius);
    graphics_fill_circle(ctx, GPoint(screen_width - 1 - x, y), radius);
  }

  if (phase == 0 && center >= start && center <= end) {
    graphics_fill_circle(ctx, GPoint(center, y), radius);
  }
}

static void prv_draw_vertical_dot_run(GContext *ctx, int x, int start,
                                      int end, int radius, int phase,
                                      int screen_height) {
  const int origin = screen_height / 2 + phase;
  const int first = prv_first_grid_point(start, origin);
  const int center = screen_height / 2;

  for (int y = first; y < center; y += DOT_SPACING) {
    graphics_fill_circle(ctx, GPoint(x, y), radius);
    graphics_fill_circle(ctx, GPoint(x, screen_height - 1 - y), radius);
  }

  if (phase == 0 && center >= start && center <= end) {
    graphics_fill_circle(ctx, GPoint(x, center), radius);
  }
}

static void prv_draw_corner_connector(GContext *ctx, int left, int top,
                                      int right, int bottom,
                                      int horizontal_point,
                                      int vertical_point, int corner_radius,
                                      int dot_radius,
                                      bool mirror_x, bool mirror_y) {
  int horizontal_gap = mirror_x
      ? right - corner_radius - horizontal_point
      : horizontal_point - (left + corner_radius);
  int vertical_gap = mirror_y
      ? bottom - corner_radius - vertical_point
      : vertical_point - (top + corner_radius);

  if (horizontal_gap < 0) {
    horizontal_gap = 0;
  }
  if (vertical_gap < 0) {
    vertical_gap = 0;
  }

  // 1.57 approximates one quarter of a circle's circumference.
  const int corner_arc_length = (corner_radius * 157 + 50) / 100;
  const int total_length =
      horizontal_gap + corner_arc_length + vertical_gap;
  // Round to the nearest number of 10 px intervals. The display-edge geometry
  // is symmetric, so every mirrored corner receives the same interval count.
  int interval_count = (total_length + DOT_SPACING / 2) / DOT_SPACING;
  if (interval_count < 2) {
    interval_count = 2;
  }

  for (int i = 1; i < interval_count; i++) {
    const int distance =
        (i * total_length + interval_count / 2) / interval_count;
    int x;
    int y;

    if (distance <= horizontal_gap) {
      x = corner_radius + horizontal_gap - distance;
      y = 0;
    } else if (distance < horizontal_gap + corner_arc_length) {
      const int arc_distance = distance - horizontal_gap;
      const int32_t angle =
          (int32_t)arc_distance * (TRIG_MAX_ANGLE / 4) /
          corner_arc_length;
      x = corner_radius -
          (corner_radius * sin_lookup(angle) + TRIG_MAX_RATIO / 2) /
              TRIG_MAX_RATIO;
      y = corner_radius -
          (corner_radius * cos_lookup(angle) + TRIG_MAX_RATIO / 2) /
              TRIG_MAX_RATIO;
    } else {
      x = 0;
      y = corner_radius +
          distance - horizontal_gap - corner_arc_length;
    }

    const int screen_x = mirror_x ? right - x : left + x;
    const int screen_y = mirror_y ? bottom - y : top + y;
    graphics_fill_circle(ctx, GPoint(screen_x, screen_y), dot_radius);
  }
}

static void prv_draw_rounded_dot_ring(GContext *ctx, GRect bounds, int depth,
                                      int dot_radius, int ring_index) {
  const int left = depth;
  const int top = depth;
  const int right = bounds.size.w - 1 - depth;
  const int bottom = bounds.size.h - 1 - depth;
  int corner_radius = DOT_OUTER_CORNER_RADIUS - depth;
  if (corner_radius < 4) {
    corner_radius = 4;
  }
  const int phase = ring_index % 2 == 0 ? 0 : DOT_SPACING / 2;
  const int horizontal_start = left + corner_radius;
  const int horizontal_end = right - corner_radius;
  const int vertical_start = top + corner_radius;
  const int vertical_end = bottom - corner_radius;
  const int horizontal_origin = bounds.size.w / 2 + phase;
  const int vertical_origin = bounds.size.h / 2 + phase;
  const int first_horizontal =
      prv_first_grid_point(horizontal_start, horizontal_origin);
  const int last_horizontal = bounds.size.w - 1 - first_horizontal;
  const int first_vertical =
      prv_first_grid_point(vertical_start, vertical_origin);
  const int last_vertical = bounds.size.h - 1 - first_vertical;
  // Every side uses the same fixed grid. The middle ring is always exactly a
  // half-step out of phase, so the zig-zag cannot drift or stretch.
  prv_draw_horizontal_dot_run(ctx, top, horizontal_start, horizontal_end,
                              dot_radius, phase, bounds.size.w);
  prv_draw_horizontal_dot_run(ctx, bottom, horizontal_start, horizontal_end,
                              dot_radius, phase, bounds.size.w);
  prv_draw_vertical_dot_run(ctx, left, vertical_start, vertical_end,
                            dot_radius, phase, bounds.size.h);
  prv_draw_vertical_dot_run(ctx, right, vertical_start, vertical_end,
                            dot_radius, phase, bounds.size.h);

  // Each connector is fitted between the actual nearest side dots. This is
  // essential on the 200 x 228 display, where a mirrored hand-made pattern
  // otherwise overlaps at one end and leaves a gap at the other.
  prv_draw_corner_connector(ctx, left, top, right, bottom, first_horizontal,
                            first_vertical, corner_radius, dot_radius,
                            false, false);
  prv_draw_corner_connector(ctx, left, top, right, bottom, last_horizontal,
                            first_vertical, corner_radius, dot_radius,
                            true, false);
  prv_draw_corner_connector(ctx, left, top, right, bottom, last_horizontal,
                            last_vertical, corner_radius, dot_radius,
                            true, true);
  prv_draw_corner_connector(ctx, left, top, right, bottom, first_horizontal,
                            last_vertical, corner_radius, dot_radius,
                            false, true);
}

static int prv_layout_value(int full_value, int timeline_value,
                            int visible_height) {
  if (visible_height >= FULL_LAYOUT_HEIGHT) {
    return full_value;
  }
  if (visible_height <= TIMELINE_LAYOUT_HEIGHT) {
    return timeline_value;
  }

  const int range = FULL_LAYOUT_HEIGHT - TIMELINE_LAYOUT_HEIGHT;
  const int progress = visible_height - TIMELINE_LAYOUT_HEIGHT;
  return timeline_value +
         ((full_value - timeline_value) * progress + range / 2) / range;
}

static void prv_set_text_pair_layout(TextLayer *shadow_layer,
                                     TextLayer *text_layer, GRect frame,
                                     GFont font, int shadow_offset) {
  text_layer_set_font(shadow_layer, font);
  text_layer_set_font(text_layer, font);

  GRect shadow_frame = frame;
  shadow_frame.origin.x += shadow_offset;
  shadow_frame.origin.y += shadow_offset;
  layer_set_frame(text_layer_get_layer(shadow_layer), shadow_frame);
  layer_set_frame(text_layer_get_layer(text_layer), frame);
}

static GFont prv_get_large_time_font(int available_width) {
  // Use the largest prepared bitmap font that fits the current digits. This
  // keeps both a wide time such as 00:00 and a narrow one such as 11:11 close
  // to the PT2 display edges without ever cropping a glyph.
  const GRect measurement_box = GRect(0, 0, 320, 130);

  for (int i = LARGE_TIME_FONT_COUNT - 1; i >= 0; i--) {
    const GSize size = graphics_text_layout_get_content_size(
        s_time_buffer, s_large_time_fonts[i], measurement_box,
        GTextOverflowModeFill, GTextAlignmentCenter);
    if (size.w <= available_width) {
      return s_large_time_fonts[i];
    }
  }

  return s_large_time_fonts[0];
}

static bool prv_date_fits(GFont font, int available_width) {
  const GSize size = graphics_text_layout_get_content_size(
      s_date_buffer, font, GRect(0, 0, 320, 60),
      GTextOverflowModeFill, GTextAlignmentCenter);
  return size.w <= available_width;
}

static GFont prv_get_date_font(GFont preferred, int available_width) {
  if (prv_date_fits(preferred, available_width)) {
    return preferred;
  }
  if (preferred == s_large_date_font &&
      prv_date_fits(s_date_font, available_width)) {
    return s_date_font;
  }
  if (preferred != s_compact_date_font &&
      prv_date_fits(s_compact_date_font, available_width)) {
    return s_compact_date_font;
  }
  return s_small_date_font;
}


static bool prv_text_fits(const char *text, GFont font, int width, int height) {
  const GSize size = graphics_text_layout_get_content_size(
      text, font, GRect(0, 0, 2048, 150), GTextOverflowModeFill, GTextAlignmentCenter);
  return size.w <= width && size.h <= height;
}

static GFont prv_get_stacked_time_font(int width) {
  // A shared size keeps the two rows aligned even when the 12-hour hour has a
  // single digit. Cap at96 so the two cap-height rows fit the vertical budget.
  for (int i = 4; i >= 0; --i) {
    if (prv_text_fits(s_hours_buffer, s_large_time_fonts[i], width, 100) &&
        prv_text_fits(s_minutes_buffer, s_large_time_fonts[i], width, 100)) {
      return s_large_time_fonts[i];
    }
  }
  const GFont smaller[] = {s_time_font, s_large_compact_time_font, s_compact_time_font};
  for (size_t i = 0; i < sizeof(smaller) / sizeof(smaller[0]); ++i) {
    if (prv_text_fits(s_hours_buffer, smaller[i], width, 100) &&
        prv_text_fits(s_minutes_buffer, smaller[i], width, 100)) { return smaller[i]; }
  }
  return s_compact_time_font;
}



static GRect prv_layout_rect(WatchLayoutRect rect) {
  return GRect(rect.x, rect.y, rect.width, rect.height);
}

static void prv_clear_complication_cache(void) {
  for (unsigned i = 0; i < COMPLICATION_CACHE_CHUNKS; ++i) {
    persist_delete(PERSIST_KEY_COMPLICATION_FIRST + i);
  }
}

static void prv_record_freshness(void) {
  const time_t now = time(NULL);
  for (unsigned i = 0; i < COMPLICATION_SLOT_COUNT; ++i) {
    s_was_fresh[i] = s_has_complications && complication_is_fresh(&s_complications.slots[i], now);
  }
}

static void prv_save_complications(void) {
  const size_t count = (s_complication_packet_length + COMPLICATION_CACHE_CHUNK_BYTES - 1) /
      COMPLICATION_CACHE_CHUNK_BYTES;
  // Commit the header chunk last. Any interrupted write is rejected by the
  // packet length and CRC on relaunch instead of displaying a mixed snapshot.
  for (size_t pass = 1; pass <= count; ++pass) {
    const size_t index = pass == count ? 0 : pass;
    const size_t offset = index * COMPLICATION_CACHE_CHUNK_BYTES;
    const size_t remaining = s_complication_packet_length - offset;
    const size_t length = remaining < COMPLICATION_CACHE_CHUNK_BYTES
        ? remaining : COMPLICATION_CACHE_CHUNK_BYTES;
    if (persist_write_data(PERSIST_KEY_COMPLICATION_FIRST + index,
                           s_complication_packet + offset, length) != (int)length) {
      prv_clear_complication_cache();
      return;
    }
  }
  for (size_t i = count; i < COMPLICATION_CACHE_CHUNKS; ++i) {
    persist_delete(PERSIST_KEY_COMPLICATION_FIRST + i);
  }
}

static void prv_load_complications(void) {
  const int first_length = persist_get_size(PERSIST_KEY_COMPLICATION_FIRST);
  if (first_length < COMPLICATION_HEADER_BYTES || first_length > COMPLICATION_CACHE_CHUNK_BYTES ||
      persist_read_data(PERSIST_KEY_COMPLICATION_FIRST, s_complication_packet,
                        COMPLICATION_CACHE_CHUNK_BYTES) != first_length) { return; }
  const size_t length = complications_u16(s_complication_packet + 2);
  if (length < COMPLICATION_HEADER_BYTES || length > COMPLICATION_MAX_BYTES ||
      first_length != (int)(length < COMPLICATION_CACHE_CHUNK_BYTES
          ? length : COMPLICATION_CACHE_CHUNK_BYTES)) { return; }
  const size_t count = (length + COMPLICATION_CACHE_CHUNK_BYTES - 1) / COMPLICATION_CACHE_CHUNK_BYTES;
  for (size_t i = 1; i < count; ++i) {
    const size_t offset = i * COMPLICATION_CACHE_CHUNK_BYTES;
    const size_t remaining = length - offset;
    const size_t chunk = remaining < COMPLICATION_CACHE_CHUNK_BYTES
        ? remaining : COMPLICATION_CACHE_CHUNK_BYTES;
    if (persist_get_size(PERSIST_KEY_COMPLICATION_FIRST + i) != (int)chunk ||
        persist_read_data(PERSIST_KEY_COMPLICATION_FIRST + i, s_complication_packet + offset,
                          chunk) != (int)chunk) { return; }
  }
  if (complications_read(s_complication_packet, length, &s_complications)) {
    s_has_complications = true;
    s_complication_packet_length = length;
    prv_record_freshness();
  }
}

static void prv_remove_legacy_data(void) {
  // Keys2..7 are still theme/clock settings;16 is still the layout. Never
  // reuse or read the obsolete provider-specific values as generic slot data.
  static const uint8_t keys[] = {1, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18};
  for (size_t i = 0; i < sizeof(keys) / sizeof(keys[0]); ++i) { persist_delete(keys[i]); }
}

static bool prv_slot_text(const ComplicationSlot *slot, char *text, size_t capacity) {
  text[0] = '\0';
  if (!complication_is_fresh(slot, time(NULL))) {
    snprintf(text, capacity, "--");
    return true;
  }
  if (slot->flags & COMPLICATION_FLAG_TIMESTAMP) {
    const time_t value = (time_t)slot->timestamp;
    struct tm *local = value >= 0 && (uint64_t)value == slot->timestamp ? localtime(&value) : NULL;
    if (local != NULL && strftime(text, capacity, s_use_12_hour ? "%I:%M" : "%H:%M", local)) {
      if (s_use_12_hour && text[0] == '0') { memmove(text, text + 1, strlen(text)); }
      return true;
    }
    snprintf(text, capacity, "--");
    return true;
  }
  if ((slot->flags & COMPLICATION_FLAG_TEXT) && slot->text_length) {
    snprintf(text, capacity, "%s", slot->text);
    return true;
  }
  return false;
}

static GFont prv_fit_complication(char *text, size_t capacity, int width, int height, int preferred) {
  for (unsigned i = 0; i < COMPLICATION_FONT_COUNT; ++i) {
    if (s_complication_font_sizes[i] <= preferred &&
        prv_text_fits(text, s_complication_fonts[i], width, height)) { return s_complication_fonts[i]; }
  }
  const GFont smallest = s_complication_fonts[COMPLICATION_FONT_COUNT - 1];
  if (!prv_text_fits(text, smallest, width, height)) {
    char prefix[COMPLICATION_MAX_TEXT_BYTES + 1];
    snprintf(prefix, sizeof(prefix), "%s", text);
    do {
      watch_layout_pop_utf8(prefix);
      snprintf(text, capacity, "%s…", prefix);
    } while (prefix[0] && !prv_text_fits(text, smallest, width, height));
  }
  return smallest;
}

static void prv_draw_bitmap(GContext *ctx, const ComplicationSlot *slot,
                            int x, int y, int size, bool shadow) {
  const int longest = slot->width > slot->height ? slot->width : slot->height;
  if (longest <= 0) { return; }
  const int width = (slot->width * size + longest / 2) / longest;
  const int height = (slot->height * size + longest / 2) / longest;
  x += (size - width) / 2;
  y += (size - height) / 2;
  for (int row = 0; row < height; ++row) {
    const int sy = row * slot->height / height;
    for (int column = 0; column < width; ++column) {
      const int sx = column * slot->width / width;
      const uint8_t pair = slot->bitmap[sy * slot->stride + sx / 2];
      const uint8_t index = sx % 2 ? pair & 15 : pair >> 4;
      const uint8_t source = slot->palette[index];
      if (!(source & 0xc0)) { continue; }
      GColor8 color = {.argb = source};
      if (shadow) { color = GColorBlack; }
      else if (!(slot->flags & COMPLICATION_FLAG_IMAGE)) {
        color.argb = (s_text_color.argb & 0x3f) | (source & 0xc0);
      }
      graphics_context_set_fill_color(ctx, color);
      graphics_fill_rect(ctx, GRect(x + column, y + row, 1, 1), 0, GCornerNone);
    }
  }
}

static void prv_draw_complication(Layer *layer, GContext *ctx) {
  const unsigned index = *(uint8_t *)layer_get_data(layer);
  if (!s_has_complications || index >= COMPLICATION_SLOT_COUNT) { return; }
  const ComplicationSlot *slot = &s_complications.slots[index];
  if (!complication_is_selected(slot)) { return; }
  const GRect bounds = layer_get_bounds(layer);
  const bool fresh = complication_is_fresh(slot, time(NULL));
  bool bitmap = fresh && (slot->flags & COMPLICATION_FLAG_BITMAP);
  char text[COMPLICATION_MAX_TEXT_BYTES + 5];
  bool has_text = prv_slot_text(slot, text, sizeof(text));
  if (!has_text && !bitmap) { snprintf(text, sizeof(text), "--"); has_text = true; }
  const int bitmap_size = bitmap ? (has_text ? 16 : 24) : 0;
  const int gap = bitmap && has_text ? 4 : 0;
  const WatchLayoutGeometry geometry = watch_layout_geometry(s_layout_style,
      layer_get_unobstructed_bounds(s_window_layer).size.h, s_large_text_enabled);
  const int preferred = geometry.slots[index].font_size;
  GFont font = s_complication_fonts[COMPLICATION_FONT_COUNT - 1];
  GSize text_size = GSize(0, 0);
  if (has_text) {
    font = prv_fit_complication(text, sizeof(text), bounds.size.w - bitmap_size - gap - 2,
                                bounds.size.h, preferred);
    text_size = graphics_text_layout_get_content_size(text, font, GRect(0, 0, 2048, 100),
        GTextOverflowModeFill, GTextAlignmentCenter);
  }
  const int text_width = has_text ? text_size.w + 2 : 0;
  const int group_width = bitmap_size + gap + text_width;
  const int x = (bounds.size.w - group_width) / 2;
  if (bitmap) {
    const int y = (bounds.size.h - bitmap_size) / 2;
    if (s_text_shadow_enabled && !(slot->flags & COMPLICATION_FLAG_IMAGE)) {
      prv_draw_bitmap(ctx, slot, x + 1, y + 1, bitmap_size, true);
    }
    prv_draw_bitmap(ctx, slot, x, y, bitmap_size, false);
  }
  if (has_text) {
    const GRect frame = GRect(x + bitmap_size + gap, (bounds.size.h - text_size.h) / 2,
                              text_width, bounds.size.h);
    if (s_text_shadow_enabled) {
      graphics_context_set_text_color(ctx, GColorBlack);
      graphics_draw_text(ctx, text, font, GRect(frame.origin.x + 1, frame.origin.y + 1,
          frame.size.w, frame.size.h), GTextOverflowModeFill, GTextAlignmentCenter, NULL);
    }
    graphics_context_set_text_color(ctx, s_text_color);
    graphics_draw_text(ctx, text, font, frame, GTextOverflowModeFill, GTextAlignmentCenter, NULL);
  }
}

static void prv_draw_background(Layer *layer, GContext *ctx) {
  const GRect layer_bounds = layer_get_bounds(layer);
  const GRect bounds = layer_get_unobstructed_bounds(s_window_layer != NULL ? s_window_layer : layer);
  graphics_context_set_antialiased(ctx, true);
  graphics_context_set_fill_color(ctx, GColorBlack);
  graphics_fill_rect(ctx, layer_bounds, 0, GCornerNone);
  graphics_context_set_fill_color(ctx, s_background_color);
  graphics_fill_rect(ctx, bounds, DOT_OUTER_CORNER_RADIUS, GCornersAll);
  const WatchLayoutStyle style = watch_layout_effective(s_layout_style, bounds.size.h);
  const WatchLayoutGeometry geometry = watch_layout_geometry(style, bounds.size.h, s_large_text_enabled);
  const bool right_selected = s_has_complications &&
      (complication_is_selected(&s_complications.slots[1]) ||
       complication_is_selected(&s_complications.slots[2]) ||
       complication_is_selected(&s_complications.slots[3]));
  if (geometry.divider_x && (style == WATCH_LAYOUT_STACKED || right_selected)) {
    graphics_context_set_stroke_color(ctx, GColorBlack);
    graphics_context_set_stroke_width(ctx, 2);
    graphics_draw_line(ctx, GPoint(geometry.divider_x, geometry.divider_top),
                       GPoint(geometry.divider_x, geometry.divider_bottom));
  }
  graphics_context_set_fill_color(ctx, GColorBlack);
  const int *dot_depths = s_depth_effect_enabled ? s_depth_dot_depths : s_classic_dot_depths;
  const int *dot_radii = s_depth_effect_enabled ? s_depth_dot_radii : s_classic_dot_radii;
  const int transition_steps = s_depth_effect_enabled ? DEPTH_DOT_TRANSITION_STEPS
                                                     : CLASSIC_DOT_TRANSITION_STEPS;
  for (int step = 0; step < transition_steps; ++step) {
    prv_draw_rounded_dot_ring(ctx, bounds, dot_depths[step], dot_radii[step], step);
  }
}

static void prv_apply_unobstructed_layout(void) {
  if (s_window_layer == NULL || s_date_layer == NULL || s_time_layer == NULL ||
      s_minutes_layer == NULL) { return; }
  const GRect root_bounds = layer_get_bounds(s_window_layer);
  const int visible_height = layer_get_unobstructed_bounds(s_window_layer).size.h;
  if (!s_compact_layout && visible_height <= COMPACT_FONT_ENTER_HEIGHT) { s_compact_layout = true; }
  else if (s_compact_layout && visible_height >= COMPACT_FONT_EXIT_HEIGHT) { s_compact_layout = false; }
  const int date_x = s_large_text_enabled ? 2 : 8;
  const int date_width = root_bounds.size.w - date_x * 2;
  const GFont preferred_date = s_compact_layout
      ? (s_large_text_enabled ? s_date_font : s_compact_date_font)
      : (s_large_text_enabled ? s_large_date_font : s_date_font);
  const GFont date_font = prv_get_date_font(preferred_date, date_width - (s_text_shadow_enabled ? 2 : 0));
  const GFont time_font = s_compact_layout
      ? (s_large_text_enabled ? s_large_compact_time_font : s_compact_time_font)
      : (s_large_text_enabled ? prv_get_large_time_font(root_bounds.size.w -
          (s_text_shadow_enabled ? 4 : 2)) : s_time_font);
  prv_set_text_pair_layout(s_date_shadow_layer, s_date_layer,
      GRect(date_x, prv_layout_value(s_large_text_enabled ? 24 : 28,
          s_large_text_enabled ? 24 : TIMELINE_DATE_Y, visible_height), date_width,
          prv_layout_value(s_large_text_enabled ? 44 : 38,
          s_large_text_enabled ? 34 : 30, visible_height)), date_font, 1);
  prv_set_text_pair_layout(s_time_shadow_layer, s_time_layer,
      GRect(0, prv_layout_value(s_large_text_enabled ? 34 : 52,
          s_large_text_enabled ? 41 : TIMELINE_TIME_Y, visible_height), root_bounds.size.w,
          prv_layout_value(s_large_text_enabled ? 120 : 102,
          s_large_text_enabled ? 86 : 78, visible_height)), time_font, 2);
  text_layer_set_text(s_date_layer, s_date_buffer);
  text_layer_set_text(s_date_shadow_layer, s_date_buffer);
  text_layer_set_text(s_time_layer, s_time_buffer);
  text_layer_set_text(s_time_shadow_layer, s_time_buffer);
  layer_set_hidden(text_layer_get_layer(s_minutes_layer), true);
  layer_set_hidden(text_layer_get_layer(s_minutes_shadow_layer), true);
  const WatchLayoutStyle style = watch_layout_effective(s_layout_style, visible_height);
  const WatchLayoutGeometry geometry = watch_layout_geometry(s_layout_style, visible_height, s_large_text_enabled);
  if (style != WATCH_LAYOUT_CLASSIC) {
    const GFont header_font = prv_get_date_font(s_large_text_enabled ? s_date_font : s_compact_date_font,
        geometry.date.width - (s_text_shadow_enabled ? 2 : 0));
    prv_set_text_pair_layout(s_date_shadow_layer, s_date_layer,
                            prv_layout_rect(geometry.date), header_font, 1);
    if (style == WATCH_LAYOUT_COMIC_COVER) {
      prv_set_text_pair_layout(s_time_shadow_layer, s_time_layer, prv_layout_rect(geometry.time),
          s_large_text_enabled ? prv_get_large_time_font(root_bounds.size.w -
          (s_text_shadow_enabled ? 4 : 2)) : s_time_font, 2);
    } else {
      const GFont stacked = prv_get_stacked_time_font(geometry.time.width - (s_text_shadow_enabled ? 2 : 0));
      text_layer_set_text(s_time_layer, s_hours_buffer);
      text_layer_set_text(s_time_shadow_layer, s_hours_buffer);
      text_layer_set_text(s_minutes_layer, s_minutes_buffer);
      text_layer_set_text(s_minutes_shadow_layer, s_minutes_buffer);
      prv_set_text_pair_layout(s_time_shadow_layer, s_time_layer, prv_layout_rect(geometry.time), stacked, 2);
      prv_set_text_pair_layout(s_minutes_shadow_layer, s_minutes_layer, prv_layout_rect(geometry.minutes), stacked, 2);
      layer_set_hidden(text_layer_get_layer(s_minutes_layer), false);
      layer_set_hidden(text_layer_get_layer(s_minutes_shadow_layer), !s_text_shadow_enabled);
    }
  }
  for (unsigned i = 0; i < COMPLICATION_SLOT_COUNT; ++i) {
    const bool visible = s_has_complications && complication_is_selected(&s_complications.slots[i]) &&
        geometry.slots[i].rect.width > 0;
    layer_set_frame(s_complication_layers[i], prv_layout_rect(geometry.slots[i].rect));
    layer_set_hidden(s_complication_layers[i], !visible);
    layer_mark_dirty(s_complication_layers[i]);
  }
  layer_mark_dirty(s_background_layer);
}

static void prv_update_clock(void) {
  const time_t now = time(NULL);
  struct tm *current_time = localtime(&now);
  const char *const *localized_days = prv_get_localized_days();

  strftime(s_time_buffer, sizeof(s_time_buffer),
           s_use_12_hour ? "%I:%M" : "%H:%M", current_time);
  if (s_use_12_hour && s_time_buffer[0] == '0') {
    memmove(s_time_buffer, s_time_buffer + 1, strlen(s_time_buffer));
  }
  watch_layout_split_time(s_time_buffer, s_hours_buffer, s_minutes_buffer);
  snprintf(s_date_buffer, sizeof(s_date_buffer), "%s · %d. %d.",
           localized_days[current_time->tm_wday], current_time->tm_mday,
           current_time->tm_mon + 1);

  text_layer_set_text(s_time_layer, s_time_buffer);
  text_layer_set_text(s_date_layer, s_date_buffer);
  text_layer_set_text(s_time_shadow_layer, s_time_buffer);
  text_layer_set_text(s_date_shadow_layer, s_date_buffer);

  // Re-evaluate every minute: extra-large time follows the current digits and
  // long localized weekday names can select the compact date font.
  prv_apply_unobstructed_layout();
}


static void prv_request_complications(void) {
  DictionaryIterator *iterator;
  const AppMessageResult result = app_message_outbox_begin(&iterator);
  if (result != APP_MSG_OK || iterator == NULL) {
    APP_LOG(APP_LOG_LEVEL_WARNING, "Could not begin complication request: %d", result);
    return;
  }
  dict_write_uint8(iterator, MESSAGE_KEY_REQUEST_COMPLICATIONS, 1);
  const AppMessageResult sent = app_message_outbox_send();
  if (sent != APP_MSG_OK) { APP_LOG(APP_LOG_LEVEL_WARNING, "Complication request failed: %d", sent); }
}

static void prv_startup_request(void *context) {
  s_startup_timer = NULL;
  prv_request_complications();
}

static void prv_phone_connection_changed(bool connected) {
  if (connected) {
    if (s_startup_timer != NULL) { app_timer_cancel(s_startup_timer); }
    s_startup_timer = app_timer_register(1000, prv_startup_request, NULL);
  }
}

static void prv_tick_handler(struct tm *tick_time, TimeUnits units_changed) {
  bool expired = false;
  const time_t now = time(NULL);
  for (unsigned i = 0; i < COMPLICATION_SLOT_COUNT; ++i) {
    const bool fresh = s_has_complications && complication_is_fresh(&s_complications.slots[i], now);
    if (s_was_fresh[i] && !fresh && s_complications.slots[i].status == COMPLICATION_STATUS_READY) {
      expired = true;
    }
    s_was_fresh[i] = fresh;
  }
  prv_update_clock();
  // One request on the freshness transition; denied/unavailable slots do not
  // cause a polling loop. Provider refresh policies belong to the phone host.
  if (expired) { prv_request_complications(); }
}

static void prv_unobstructed_area_will_change(GRect final_area, void *context) {
  prv_apply_unobstructed_layout();
}
static void prv_unobstructed_area_change(AnimationProgress progress, void *context) {
  prv_apply_unobstructed_layout();
}
static void prv_unobstructed_area_did_change(void *context) { prv_apply_unobstructed_layout(); }

static void prv_apply_colors(void) {
  if (s_window != NULL) { window_set_background_color(s_window, s_background_color); }
  if (s_date_layer != NULL) { text_layer_set_text_color(s_date_layer, s_text_color); }
  if (s_time_layer != NULL) { text_layer_set_text_color(s_time_layer, s_text_color); }
  if (s_minutes_layer != NULL) { text_layer_set_text_color(s_minutes_layer, s_text_color); }
  prv_apply_unobstructed_layout();
}

static void prv_apply_effects(void) {
  if (s_date_shadow_layer != NULL) {
    layer_set_hidden(text_layer_get_layer(s_date_shadow_layer), !s_text_shadow_enabled);
  }
  if (s_time_shadow_layer != NULL) {
    layer_set_hidden(text_layer_get_layer(s_time_shadow_layer), !s_text_shadow_enabled);
  }
  prv_apply_unobstructed_layout();
}

static void prv_inbox_received(DictionaryIterator *iterator, void *context) {
  Tuple *data = dict_find(iterator, MESSAGE_KEY_COMPLICATION_DATA);
  if (data != NULL) {
    if (data->type == TUPLE_BYTE_ARRAY && data->length <= COMPLICATION_MAX_BYTES &&
        complications_read(data->value->data, data->length, &s_complications)) {
      s_has_complications = true;
      s_complication_packet_length = data->length;
      memcpy(s_complication_packet, data->value->data, s_complication_packet_length);
      prv_record_freshness();
      prv_save_complications();
      prv_remove_legacy_data();
    } else {
      s_has_complications = false;
      s_complication_packet_length = 0;
      memset(&s_complications, 0, sizeof(s_complications));
      memset(s_was_fresh, 0, sizeof(s_was_fresh));
      prv_clear_complication_cache();
    }
  }
  Tuple *background = dict_find(iterator, MESSAGE_KEY_BACKGROUND_COLOR);
  Tuple *text = dict_find(iterator, MESSAGE_KEY_TEXT_COLOR);
  Tuple *depth = dict_find(iterator, MESSAGE_KEY_DEPTH_EFFECT);
  Tuple *shadow = dict_find(iterator, MESSAGE_KEY_TEXT_SHADOW);
  Tuple *large = dict_find(iterator, MESSAGE_KEY_LARGE_TEXT);
  Tuple *twelve = dict_find(iterator, MESSAGE_KEY_USE_12_HOUR);
  Tuple *layout = dict_find(iterator, MESSAGE_KEY_LAYOUT_STYLE);
  if (background != NULL) {
    s_background_color = GColorFromHEX(background->value->int32);
    persist_write_int(PERSIST_KEY_BACKGROUND_COLOR, background->value->int32);
  }
  if (text != NULL) {
    s_text_color = GColorFromHEX(text->value->int32);
    persist_write_int(PERSIST_KEY_TEXT_COLOR, text->value->int32);
  }
  if (depth != NULL) {
    s_depth_effect_enabled = depth->value->int32 != 0;
    persist_write_bool(PERSIST_KEY_DEPTH_EFFECT, s_depth_effect_enabled);
  }
  if (shadow != NULL) {
    s_text_shadow_enabled = shadow->value->int32 != 0;
    persist_write_bool(PERSIST_KEY_TEXT_SHADOW, s_text_shadow_enabled);
  }
  if (large != NULL) {
    s_large_text_enabled = large->value->int32 != 0;
    persist_write_bool(PERSIST_KEY_LARGE_TEXT, s_large_text_enabled);
  }
  if (twelve != NULL) {
    s_use_12_hour = twelve->value->int32 != 0;
    persist_write_bool(PERSIST_KEY_USE_12_HOUR, s_use_12_hour);
  }
  if (layout != NULL && (layout->type == TUPLE_INT || layout->type == TUPLE_UINT)) {
    s_layout_style = watch_layout_sanitize(layout->value->int32);
    persist_write_int(PERSIST_KEY_LAYOUT_STYLE, s_layout_style);
  }
  prv_update_clock();
  prv_apply_colors();
  prv_apply_effects();
}

static void prv_inbox_dropped(AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_WARNING, "Complication message dropped: %d", reason);
}
static void prv_outbox_failed(DictionaryIterator *iterator, AppMessageResult reason, void *context) {
  APP_LOG(APP_LOG_LEVEL_WARNING, "Complication request failed: %d", reason);
}

static void prv_configure_text_layer(TextLayer *layer, GFont font) {
  text_layer_set_background_color(layer, GColorClear);
  text_layer_set_text_color(layer, s_text_color);
  text_layer_set_text_alignment(layer, GTextAlignmentCenter);
  text_layer_set_overflow_mode(layer, GTextOverflowModeFill);
  text_layer_set_font(layer, font);
}

static void prv_configure_shadow_layer(TextLayer *layer, GFont font) {
  text_layer_set_background_color(layer, GColorClear);
  text_layer_set_text_color(layer, GColorBlack);
  text_layer_set_text_alignment(layer, GTextAlignmentCenter);
  text_layer_set_overflow_mode(layer, GTextOverflowModeFill);
  text_layer_set_font(layer, font);
}


static void prv_window_load(Window *window) {
  s_window_layer = window_get_root_layer(window);
  const GRect bounds = layer_get_bounds(s_window_layer);
  s_background_layer = layer_create(bounds);
  layer_set_update_proc(s_background_layer, prv_draw_background);
  layer_add_child(s_window_layer, s_background_layer);
  s_date_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_24));
  s_time_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_76));
  s_compact_date_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_22));
  s_small_date_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_20));
  s_compact_time_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_64));
  s_large_date_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_28));
  s_large_time_fonts[0] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_80));
  s_large_time_fonts[1] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_84));
  s_large_time_fonts[2] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_88));
  s_large_time_fonts[3] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_92));
  s_large_time_fonts[4] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_96));
  s_large_time_fonts[5] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_100));
  s_large_time_fonts[6] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_104));
  s_large_time_fonts[7] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_108));
  s_large_compact_time_font = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_72));
  s_complication_fonts[0] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_COMPLICATION_38));
  s_complication_fonts[1] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_COMPLICATION_28));
  s_complication_fonts[2] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_COMPLICATION_24));
  s_complication_fonts[3] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_COMPLICATION_20));
  s_complication_fonts[4] = fonts_load_custom_font(resource_get_handle(RESOURCE_ID_FIRA_SANS_CONDENSED_BOLD_COMPLICATION_18));
  s_date_shadow_layer = text_layer_create(GRect(9, 29, bounds.size.w - 16, 38));
  prv_configure_shadow_layer(s_date_shadow_layer, s_date_font);
  layer_add_child(s_window_layer, text_layer_get_layer(s_date_shadow_layer));
  s_time_shadow_layer = text_layer_create(GRect(2, 54, bounds.size.w, 102));
  prv_configure_shadow_layer(s_time_shadow_layer, s_time_font);
  layer_add_child(s_window_layer, text_layer_get_layer(s_time_shadow_layer));
  s_minutes_shadow_layer = text_layer_create(GRect(9, 113, 96, 98));
  prv_configure_shadow_layer(s_minutes_shadow_layer, s_large_time_fonts[4]);
  layer_add_child(s_window_layer, text_layer_get_layer(s_minutes_shadow_layer));
  s_date_layer = text_layer_create(GRect(8, 28, bounds.size.w - 16, 38));
  prv_configure_text_layer(s_date_layer, s_date_font);
  layer_add_child(s_window_layer, text_layer_get_layer(s_date_layer));
  s_time_layer = text_layer_create(GRect(0, 52, bounds.size.w, 102));
  prv_configure_text_layer(s_time_layer, s_time_font);
  layer_add_child(s_window_layer, text_layer_get_layer(s_time_layer));
  s_minutes_layer = text_layer_create(GRect(7, 111, 96, 98));
  prv_configure_text_layer(s_minutes_layer, s_large_time_fonts[4]);
  layer_add_child(s_window_layer, text_layer_get_layer(s_minutes_layer));
  for (unsigned i = 0; i < COMPLICATION_SLOT_COUNT; ++i) {
    s_complication_layers[i] = layer_create_with_data(GRect(0, 0, 0, 0), sizeof(uint8_t));
    *(uint8_t *)layer_get_data(s_complication_layers[i]) = i;
    layer_set_update_proc(s_complication_layers[i], prv_draw_complication);
    layer_add_child(s_window_layer, s_complication_layers[i]);
  }
  prv_update_clock();
  prv_apply_effects();
  UnobstructedAreaHandlers handlers = {
    .will_change = prv_unobstructed_area_will_change,
    .change = prv_unobstructed_area_change,
    .did_change = prv_unobstructed_area_did_change,
  };
  unobstructed_area_service_subscribe(handlers, NULL);
}

static void prv_window_unload(Window *window) {
  unobstructed_area_service_unsubscribe();
  for (unsigned i = 0; i < COMPLICATION_SLOT_COUNT; ++i) { layer_destroy(s_complication_layers[i]); }
  text_layer_destroy(s_minutes_layer);
  text_layer_destroy(s_minutes_shadow_layer);
  text_layer_destroy(s_date_layer);
  text_layer_destroy(s_time_layer);
  text_layer_destroy(s_date_shadow_layer);
  text_layer_destroy(s_time_shadow_layer);
  fonts_unload_custom_font(s_date_font);
  fonts_unload_custom_font(s_time_font);
  fonts_unload_custom_font(s_compact_date_font);
  fonts_unload_custom_font(s_small_date_font);
  fonts_unload_custom_font(s_compact_time_font);
  fonts_unload_custom_font(s_large_date_font);
  fonts_unload_custom_font(s_large_compact_time_font);
  for (unsigned i = 0; i < LARGE_TIME_FONT_COUNT; ++i) { fonts_unload_custom_font(s_large_time_fonts[i]); }
  for (unsigned i = 0; i < COMPLICATION_FONT_COUNT; ++i) { fonts_unload_custom_font(s_complication_fonts[i]); }
  layer_destroy(s_background_layer);
  s_window_layer = NULL;
}

static void prv_init(void) {
  s_background_color = GColorOrange;
  s_text_color = GColorWhite;
  s_depth_effect_enabled = false;
  s_text_shadow_enabled = false;
  s_large_text_enabled = false;
  s_use_12_hour = false;
  s_layout_style = WATCH_LAYOUT_CLASSIC;
  if (persist_exists(PERSIST_KEY_BACKGROUND_COLOR)) {
    s_background_color = GColorFromHEX(persist_read_int(PERSIST_KEY_BACKGROUND_COLOR));
  }
  if (persist_exists(PERSIST_KEY_TEXT_COLOR)) { s_text_color = GColorFromHEX(persist_read_int(PERSIST_KEY_TEXT_COLOR)); }
  if (persist_exists(PERSIST_KEY_DEPTH_EFFECT)) { s_depth_effect_enabled = persist_read_bool(PERSIST_KEY_DEPTH_EFFECT); }
  if (persist_exists(PERSIST_KEY_TEXT_SHADOW)) { s_text_shadow_enabled = persist_read_bool(PERSIST_KEY_TEXT_SHADOW); }
  if (persist_exists(PERSIST_KEY_LARGE_TEXT)) { s_large_text_enabled = persist_read_bool(PERSIST_KEY_LARGE_TEXT); }
  if (persist_exists(PERSIST_KEY_USE_12_HOUR)) { s_use_12_hour = persist_read_bool(PERSIST_KEY_USE_12_HOUR); }
  if (persist_exists(PERSIST_KEY_LAYOUT_STYLE)) {
    s_layout_style = watch_layout_sanitize(persist_read_int(PERSIST_KEY_LAYOUT_STYLE));
  }
  prv_load_complications();
  s_window = window_create();
  window_set_background_color(s_window, s_background_color);
  window_set_window_handlers(s_window, (WindowHandlers){.load = prv_window_load, .unload = prv_window_unload});
  app_message_register_inbox_received(prv_inbox_received);
  app_message_register_inbox_dropped(prv_inbox_dropped);
  app_message_register_outbox_failed(prv_outbox_failed);
  app_message_open(2048, 32);
  tick_timer_service_subscribe(MINUTE_UNIT, prv_tick_handler);
  window_stack_push(s_window, false);
  connection_service_subscribe((ConnectionHandlers){.pebble_app_connection_handler = prv_phone_connection_changed});
  s_startup_timer = app_timer_register(1000, prv_startup_request, NULL);
}

static void prv_deinit(void) {
  if (s_startup_timer != NULL) { app_timer_cancel(s_startup_timer); }
  connection_service_unsubscribe();
  tick_timer_service_unsubscribe();
  app_message_deregister_callbacks();
  window_destroy(s_window);
}

int main(void) {
  prv_init();
  app_event_loop();
  prv_deinit();
}
