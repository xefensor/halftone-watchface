HALFTONE 1.1.0 — PEBBLE STORE RELEASE KIT

Upload these items to the Pebble Developer Dashboard:

1. Halftone-1.1.0.pbw
2. description.txt
3. release-notes.txt
4. store-assets/emery_01_orange.png
5. store-assets/emery_02_blue_large.png
6. store-assets/emery_03_green_shadow.png

The 720 × 320 banner in store-assets is optional for a watchface.
See PUBLISHING.md for the full checklist and final physical-device tests.

Halftone-1.1.0-source.zip is a clean source archive for backup or publication.
SHA256SUMS.txt contains checksums for the binary and source archive.
