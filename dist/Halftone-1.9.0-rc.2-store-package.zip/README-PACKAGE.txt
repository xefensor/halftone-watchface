Halftone 1.9.0 release candidate 2

The PBW is at the root of this archive. Listing text, five raw screenshots,
a banner and publishing instructions are in store/. Validation is in docs/.

Pebble currently asks apps using preview plugins not to be published to the
public appstore yet. This is a sideloadable candidate, not a store submission.
Physical phone/watch verification is still required. See store/PUBLISHING.md.

Check the files against SHA256SUMS.txt before uploading the exact PBW.
Project: https://github.com/xefensor/halftone-watchface
