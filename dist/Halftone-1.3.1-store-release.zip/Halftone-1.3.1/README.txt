HALFTONE 1.3.1 — PEBBLE STORE RELEASE KIT

Upload Halftone-1.3.1.pbw as a new release of the existing Halftone listing.
Keep UUID d4dd5046-53be-4624-99e8-46e0b377fe66.

This release fixes scheduled requests being ignored while the face remains open.
It accepts named and numeric AppMessage keys, adds a phone-side 30-minute
refresh timer and releases stuck location, HTTP and delivery requests.
The six-hour offline forecast cache is preserved.

Use description.txt, release-notes.txt and PRIVACY.md for the listing.
Raw screenshots and the optional banner are in store-assets.
Before publishing, follow PUBLISHING.md and verify uninterrupted refresh on
a physical Pebble Time 2. The automated suite covers the exact named-key bug,
30-minute refresh without leaving the face, lost callbacks and late responses.

Halftone-1.3.1-source.zip contains clean source, tests and license notices.
SHA256SUMS.txt contains checksums for the binary and source archive.
