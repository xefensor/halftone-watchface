# Changelog

## 1.10.2 — 2026-11-14

- Package the current reviewed implementation and updated Store assets under a new numeric version, preserving the public UUID and saved settings.
- Earlier released binaries and archives remain unchanged.

## Repository updates after rc.6

- Publishes the checked rc.6 PBW, source and prepared store archives through
  [automatic GitHub releases](docs/GITHUB-RELEASES.md), with per-release checksums
  and checks that preserve published tags and asset bytes.
- Updates setup and contributor documentation for the current two-slot layout,
  Halftone's independently pinned Core 0.1.0 and the remaining device checks.
  These repository updates do not change the published rc.6 watchface or archives.

## 1.9.0 rc.6

- Moves complication/context source handling, message transport and native
  cache/freshness/reconnect state into Pebble Watchface Core 0.1.0.
- Pins the shared package archive and lockfile, with upstream/checksum
  provenance in `vendor/CORE.json`; users still install one Halftone PBW.
- Keeps Halftone's UUID, saved settings, legacy phone cache key and native
  persistence range, notification baselines and short-lived context policy.
- Keeps the rc.5 dot border, fonts, text/artwork placement and Timeline Peek
  layout. Shared engine changes can be tested separately from this renderer.

## 1.9.0 rc.5

- Bottom-aligns visible music artwork and notification icons with the actual
  fitted foreground text, excluding its one-pixel shadow, instead of using
  the previous centered-plus-offset placement.
- Uses generated compiled-font glyph metrics after fitting and ellipsis, and
  accounts for transparent icon padding and contain-fit empty space.
- Preserves rc.4 artwork boxes: 32 pixels normally or 40 with Big text for
  two-line panels, and 28 pixels for a single line.
- Leaves clock/text positions, source artwork limits, music cropping,
  notification contain-fitting, privacy and the dot border unchanged.

## 1.9.0 rc.4

- Reduces the contextual artwork box to 32 pixels normally or 40 with Big text
  for two-line panels; single-line panels use 28 pixels.
- Applies the same box size and a 2-pixel downward offset to music artwork and
  notification icons, leaving breathing room above them.
- Keeps center-cropped, unstretched music images and contain-fit notification
  icons; the displayed artwork still determines the title inset.
- Preserves the source-artwork 24-pixel cap and the existing long-title
  hide-art rule.
- Leaves rc.3 clock fitting, both horizontal complications, dot geometry and
  notification privacy behavior unchanged.

## 1.9.0 rc.3

- Positions the clock using visible bounds measured from compiled font glyphs,
  balancing shorter times such as `22:14` without crowding taller `1:05`.
- Fits the clock to the space available above active context. The visible clock
  center is 96 pixels normally and 88 with context; Big text caps contextual
  clock fonts at 88 pixels. The clock remains still during dissolve frames.
- Keeps accented weekday tails clear of the clock across all 17 languages.
- Displays album art at the height of its two-line music block: 40 pixels
  normally, 48 with Big text, or 32 for a single-line music panel. Source
  bitmaps remain capped at 24 pixels and are scaled for display. Rectangular
  music images are center-cropped to a square without stretching; generic
  complication images and notification icons keep their contain-fit behavior.
- Sizes the title inset to the displayed artwork while retaining the existing
  rule that hides art when doing so lets the full title fit. Notification
  icons remain 24 pixels.
- Retains both horizontal complications under native Timeline Peek, Big text,
  the established dot border and the plugin-preview publishing hold.

## 1.9.0 rc.2

- Keeps both selected complications in equal horizontal columns when native
  Timeline Peek opens, instead of hiding the second reading.
- Changes the large-clock option to **Big text**, enlarging the date, clock,
  reading numbers and units, and contextual music/notification text together.
- Adds a 44-pixel reading font for Big text, compared with the standard
  38-pixel preference; long values fit down to remain readable.
- Refines compact spacing around the native Timeline area and the contextual
  panel while preserving the procedural halftone dots and rounded border.
- Preserves the saved text-size setting, source choices, and notification
  privacy defaults. Settings explanations remain localized.
- Remains a sideloaded plugin-preview candidate. Public-store submission waits
  for Pebble's preview restriction to be lifted and device checks to complete.

## 1.9.0 rc.1

- Introduced two equal horizontal complication columns, with both readings
  compacted above music or notification context.
- Refined date fitting, text margins and settings organization.
- Kept only complication 1 visible during native Timeline Peek.
- Retained the earlier extra-large clock option and existing optical effects.

Earlier release history and version-specific checks remain in
[validation](docs/VALIDATION.md).
